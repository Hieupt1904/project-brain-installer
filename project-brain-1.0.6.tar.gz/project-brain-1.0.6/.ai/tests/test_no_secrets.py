"""No secret patterns in canonical knowledge and generated files."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PATTERNS = agentctl = None


def _load():
    global PATTERNS, agentctl
    import sys
    sys.path.insert(0, str(ROOT / ".ai" / "scripts"))
    import agentctl as ag  # type: ignore
    agentctl = ag
    PATTERNS = ag.SECRET_PATTERNS


class TestNoSecrets(unittest.TestCase):
    def test_canonical_and_generated(self):
        import sys
        sys.path.insert(0, str(ROOT / ".ai" / "scripts"))
        import agentctl as ag  # type: ignore
        checked = 0
        for path in list((ROOT / ".ai" / "knowledge").rglob("*.md")) + list((ROOT / ".ai" / "policy").rglob("*.md")) + list((ROOT / ".ai" / "generated").glob("*.md")):
            text = path.read_text(encoding="utf-8")
            checked += 1
            for pattern in ag.SECRET_PATTERNS:
                self.assertIsNone(pattern.search(text), f"Secret pattern trong {path}")
        self.assertGreater(checked, 0)


if __name__ == "__main__":
    unittest.main()
