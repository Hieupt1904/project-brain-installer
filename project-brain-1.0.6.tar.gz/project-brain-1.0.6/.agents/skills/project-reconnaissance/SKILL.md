<!-- GENERATED FILE — DO NOT EDIT DIRECTLY -->
<!-- canonical: .ai/skills/project-reconnaissance/SKILL.md -->
<!-- generated_at: 2026-07-21T04:08:29+00:00 -->
<!-- source_sha256: 7cb8a713b0bc864027346c0e699ef0bcb283ea9940eb2eff2c6422156d6dc3e6 -->
<!-- schema_version: 1.0 -->

---
name: project-reconnaissance
description: Safely inventory project evidence and classify facts without guessing runtime providers or models.
---
# Project reconnaissance

Use this skill at session start or when onboarding an existing project.

1. Run `./ai start`; it regenerates `.ai/recon/inventory.json`, `evidence.json`, and `facts.json`.
2. Read safe manifests/config/source metadata only. Never read `.env` values, credentials, secret-bearing paths, symlinks, generated build trees, or external paths.
3. Label every fact `verified`, `inherited`, `inferred`, `unknown`, or `conflicted`.
4. Treat dependency/config evidence as capability evidence only. Never claim an STT/TTS model or provider unless `.ai/runtime/model-evidence.json` records runtime evidence.
5. Re-run reconnaissance whenever evidence changes; do not preserve stale conclusions.
6. Present unknown/conflicted facts explicitly and ask for runtime verification where needed.
